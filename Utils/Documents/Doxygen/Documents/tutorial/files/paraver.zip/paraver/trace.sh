#!/bin/bash

#Workaround for tracing in MN3, make TMPDIR point to an existing dir
export TMPDIR=$TMPDIR/extrae
mkdir -p $TMPDIR

export EXTRAE_HOME=/apps/CEPBATOOLS/extrae/latest/openmpi/64
source ${EXTRAE_HOME}/etc/extrae.sh

export EXTRAE_CONFIG_FILE=./extrae.xml
$@
