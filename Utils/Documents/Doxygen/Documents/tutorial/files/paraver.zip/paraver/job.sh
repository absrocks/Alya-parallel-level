#!/bin/bash

#BSUB -n 5
#BSUB -R"span[ptile=16]"
#BSUB -o output.%J.out
#BSUB -e output.%J.err
#BSUB -W 00:10
#BSUB -J trazas
#BSUB -q bsc_debug 

mpirun ./trace.sh /home/bsc21/bsc21967/alya/Executables/unix/Alya.g cavtri03 > out_mn.txt
