import numpy as np 

num = 250
filename = "cosa.txtdragforce0"

mydata = np.array([10,20])
mydata.astype('int').tofile(filename)

