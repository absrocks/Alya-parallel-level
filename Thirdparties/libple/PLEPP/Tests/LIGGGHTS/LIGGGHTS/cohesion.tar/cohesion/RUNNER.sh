rm cosa*
python ascii2bin.py 


## 2017ABR24
# compile la version del 2016, 
# y parece funcionar. 
# el caso acoplado ya no lo corri, 
# pues la parte de alya esta perdida, 
# solo rescate los archivos modificados...


## ok 
#time mpirun -np 1 /home/bsc21/bsc21704/z2016/REPOSITORY/LIGGGHTS/LIGGGHTS_2016FEB05/src/lmp_openmpi DEM < in.cohesion_cplng


#time mpirun -np 2 /home/bsc21/bsc21704/z2016/REPOSITORY/LIGGGHTS/LIGGGHTS_2016FEB05/src/lmp_openmpi DEM < in.cohesion_cplng : -np 1 /home/bsc21/bsc21704/z2016/REPOSITORY/ALYAs/ALYA_2016Feb15/Executables/plepp02/Alya.x COSA --name CFD  

#time mpirun -np 1 /home/bsc21/bsc21704/z2016/REPOSITORY/LIGGGHTS/LIGGGHTS_2016FEB05/src/lmp_openmpi DEM < in.cohesion_cplng : -np 1 /home/bsc21/bsc21704/z2016/REPOSITORY/ALYAs/ALYA_2016Feb23/Thirdparties/libple/PLEPP/Wrappers/Cpp/wloader.x CFD   

## FROM: /home/bsc21/bsc21704/z2016/REPOSITORY/LIGGGHTS/LIGGGHTS_2016FEB05/examples/LIGGGHTS/Tutorials_public/cohesion

