#ifndef LMP_NEIGHBOR_MULTI_LEVEL_GRID_H
#define LMP_NEIGHBOR_MULTI_LEVEL_GRID_H
namespace LAMMPS_NS
{

class MultiLevelGrid
{
  public:
    MultiLevelGrid() {};
    double foo;
};
}
#endif

