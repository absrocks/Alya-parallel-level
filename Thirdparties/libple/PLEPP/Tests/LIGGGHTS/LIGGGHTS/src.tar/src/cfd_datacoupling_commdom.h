/*
  CREATED: 2016FEB15 @ Barcelona, Spain   
  FROM: coupling_file.h 
*/
#ifdef CFD_DATACOUPLING_CLASS

   CfdDataCouplingStyle(commdom,CfdDatacouplingCommdom)

#else

#ifndef LMP_CFD_DATACOUPLING_COMMDOM_H
#define LMP_CFD_DATACOUPLING_COMMDOM_H

#include "cfd_datacoupling.h" // CfdDatacoupling
#include "cfd_commdom.h"      // plepp 
#include "neighbor.h"
#include "domain.h" 
#include "universe.h" 
#include "neigh_list.h" // NeighList 
#include "bounding_box.h"
#include "atom.h"

#include <algorithm>    // std::min_element, std::max_element

namespace LAMMPS_NS {

class CfdDatacouplingCommdom : public CfdDatacoupling 
{
  public:

  CfdDatacouplingCommdom(class LAMMPS *lmp, int jarg, int narg, char **arg, void* fix) : CfdDatacoupling(lmp,jarg,narg,arg,NULL) 
  {
    cout<<"[CfdDatacouplingCommdom]"<<" \n";

    plepp->init_comms(); 
  }

  virtual ~CfdDatacouplingCommdom() 
  {
  }

  void post_create()
  {
    cout<<"[post_create]"<<" \n";
//    if(comm->nprocs > 1)  error->all(FLERR,"Fix couple/cfd with file coupling is for serial computation only");
  }

  void exchange() 
  {
//neighbor->print_lists_of_lists();
    cout<<"[exchange]"<<" step:"<< update->ntimestep <<" \n"; 
/*
for(int i=0; i<8; i++)
{
 for(int j=0; j<3; j++) cout<< domain->corners[i][j] <<" "; 
 cout<<"\n";
} 
*/

  MPI_Barrier( universe->uworld ); 

int nlist = neighbor->nlist;

for(int j=0; j<3; j++) 
cout
<<" "<< universe->me <<"."<< universe->nprocs <<" "
<<" ["<< domain->boxlo[j] <<", "<< domain->boxhi[j] <<"] " 
<<" ["<< domain->sublo[j] <<", "<< domain->subhi[j] <<"] "
<<" "<< nlist <<" " 
<<" "<< neighbor->n_neighs() <<" "
<<" \n";

for(int k=0; k<nlist; k++) init_list( k,neighbor->lists ); 

    void *dummy = NULL;

    // write to file
    for(int i = 0; i < npush_; i++)
    {
      push(pushnames_[i],pushtypes_[i],dummy,"");
    }

    set_bin_pts(); 

int n_pts = pts.size()/3; 
int n_cells = connectivity.size()/8; 
    plepp->set_vertex_coords_i(n_pts, pts.data(), n_cells, connectivity.data()); 

    plepp->create_geometry( update->ntimestep ); 
    plepp->clear_vertex_coords_j();
    pts.clear();
    connectivity.clear();

    // read from files
    for(int i = 0; i < npull_; i++)
    {
      pull(pullnames_[i],pulltypes_[i],dummy,"");
    }

  }


  void push( const char *name,const char *type,void *&to,const char *datatype ) 
  {
/*
    cout<<"[push]"<<" ";
    cout<<"'"<< name <<"' ";
    cout<<"'"<< type <<"' ";
    cout<<" n_pts:"<< atom->nlocal <<"' ";
*/
    CfdDatacoupling::push(name,type,to,datatype);

    int len1 = -1, len2 = -1;
    if(t0 == -1) t0 = update->ntimestep;
    if(update->ntimestep > t0) firstexec = false;
    void * from = find_push_property(name,type,len1,len2);

    if(from && strcmp(type,"vector-atom") == 0 && strcmp(name,"x") == 0 )
    {
/*
    cout<<"[push]"<<" ";
    cout<<"'"<< name <<"' ";
    cout<<"'"<< type <<"' ";
    cout<<" n_pts:"<< atom->nlocal <<"' ";
    cout<<" \n";
*/
      double** field = (double**) from; 
      plepp->set_vertex_coords_j(atom->nlocal, field); 
    }

//    cout<<" \n";
  }


  void pull(const char *name,const char *type,void *&from,const char *datatype)
  {
/*
    cout<<"[pull]"<<" ";
    cout<<"'"<<  name <<"' ";
    CfdDatacoupling::pull(name,type,from,datatype);
    cout<<" \n";
*/
  }


  void* find_pull_property(const char *name, const char *type, int &len1, int &len2)
  { 
    return CfdDatacoupling::find_pull_property(name, type, len1, len2); 
  }

  void* find_push_property(const char *name, const char *type, int &len1, int &len2)
  { 
    return CfdDatacoupling::find_push_property(name, type, len1, len2); 
  }

  private: 
    bool firstexec;
    int  t0;


void set_bin_pts() 
{
  double* bboxlo = neighbor->bboxlo; // domain->boxlo_bound; 
  double binsizex = neighbor->binsizex;
  double binsizey = neighbor->binsizey;
  double binsizez = neighbor->binsizez;

  // setup_bins() 
  int nbinx = neighbor->nbinx;  //
  int nbiny = neighbor->nbiny;  // 
  int nbinz = neighbor->nbinz;  //  

  int n_pts = (nbinx+1)*(nbiny+1)*(nbinz+1);
//vector<double> pts;
  for(int i=0,l=0; i<nbinx+1; i++)
  {
    for(int j=0; j<nbiny+1; j++)
    {
      for(int k=0; k<nbinz+1; k++, l++)
      {
        pts.push_back( bboxlo[0] + i * binsizex );
        pts.push_back( bboxlo[1] + j * binsizey );
        pts.push_back( bboxlo[2] + k * binsizez );
      }
    }
  }

//vector<int> connectivity; 
  for(int i=0,l=0; i<nbinx; i++)
  {
    for(int j=0; j<nbiny; j++)
    {
      for(int k=0; k<nbinz; k++, l++)
      {
        vector<int> aux( get_connectivity(i,j,k) ); 
        connectivity.insert( connectivity.end(), aux.begin(), aux.end() ); 
      }
    }
  }

  for(int i=0; i<connectivity.size(); i++) connectivity[i]++; 

  cout<<" connectivity.size:"<< connectivity.size()/8 <<
        " pts.size:"<< pts.size()/3.0 <<" "<< n_pts <<"\n";    

  cout<<"mbins:"<< neighbor->mbins <<" ";
  cout<<" ("<< neighbor->nbinx <<","<< neighbor->nbiny <<","<< neighbor->nbinz <<") ";
  cout<<" ("<<  *min_element(connectivity.begin(),connectivity.end()) <<"," 
      <<" " <<  *max_element(connectivity.begin(),connectivity.end()) <<") "; 
  cout<<"\n";

  if( n_pts < *max_element(connectivity.begin(),connectivity.end()) )
  {
    cout<<" ERROR: 'maxbin<max_element(connectivity)' !!";
    exit(1);
  }

}


vector<int>
get_connectivity(int ii, int jj, int kk)
{
  int nbinx = neighbor->nbinx;  //
  int nbiny = neighbor->nbiny;  // 
  int nbinz = neighbor->nbinz;  //

      int vertices[8][3] = {
                                { 0, 0, 0 },
                                { 1, 0, 0 },
                                { 1, 1, 0 },
                                { 0, 1, 0 },
                                { 0, 0, 1 },
                                { 1, 0, 1 },
                                { 1, 1, 1 },
                                { 0, 1, 1 }
                           }; 

      vector<int> connectivity;  
      for(int l=0; l<8; l++)
      {
         int iz  = vertices[l][2]+kk; 
         int iy  = vertices[l][1]+jj; 
         int ix  = vertices[l][0]+ii; 
       //int idx = (iz-mbinzlo)*mbiny*mbinx + (iy-mbinylo)*mbinx + (ix-mbinxlo);  
         int idx = ix + (iy)*(nbinx+1) + (iz)*(nbiny+1)*(nbinx+1);  
         connectivity.push_back( idx ); 
      }

  return connectivity; 
}


    void init_list(int id, class NeighList **ptr)
    {
      list = ptr[id];
    }


    void loop_over_all_neighbors() 
    {
      double    **x = atom->x;
      int    nlocal = atom->nlocal;
      int    ntotal = atom->natoms;                // total # of atoms 

      // loop over neighbors of my atoms
      int *jlist, jnum;

      int         inum = list->inum;
      int       *ilist = list->ilist;
      int    *numneigh = list->numneigh;
      int **firstneigh = list->firstneigh;

      if(false)
      for (int ii=0,i=0; ii < inum; ii++) 
      {
        i     = ilist[ii];
        jlist = firstneigh[i];
        jnum  = numneigh[i];

        cout<< i <<" ";
        for (int jj=0, j=0; jj < jnum; jj++) 
        {
          j = jlist[jj];
          cout<< j <<" ";
        }
        cout<<"\n";
      }
    }


    void set_bin_structure() // Neighbor::setup_bins 
    { 
      // init()  
      double* bboxlo = neighbor->bboxlo; // domain->boxlo_bound; 
      double* bboxhi = neighbor->bboxhi; // domain->boxhi_bound; 

      // setup_bins() 
      int nbinx = neighbor->nbinx;  //
      int nbiny = neighbor->nbiny;  // 
      int nbinz = neighbor->nbinz;  //  
      int nbin[3] = {neighbor->nbinx, neighbor->nbiny, neighbor->nbinz}; 

      double binsizex = neighbor->binsizex;
      double binsizey = neighbor->binsizey;
      double binsizez = neighbor->binsizez;
      double binsize[3] = {neighbor->binsizex, neighbor->binsizey, neighbor->binsizez};  
      double  bininv[3] = {1.0/neighbor->binsizex, 1.0/neighbor->binsizey, 1.0/neighbor->binsizez};

      int mbinxlo = neighbor->mbinxlo;
      int mbinx   = neighbor->mbinx; 
      int   mbin[3] = {neighbor->mbinx, neighbor->mbiny, neighbor->mbinz};
      int mbinlo[3] = {neighbor->mbinxlo, neighbor->mbinylo, neighbor->mbinzlo};

      // sx,sy,sz = max range of stencil in each dim
      // Neighbor::choose_stencil -> StencilPtr sc = NULL; sc = &Neighbor::stencil_BLABLA
      // Neighbor::choose_build   ->    PairPtr pb = NULL; pb = &Neighbor::BLABLA 

plepp->set_bins(bboxlo, bboxhi, binsize, nbin, mbin, mbinlo);  

cout<<"nbinx:"<< nbinx <<" "; 
cout<<"nbiny:"<< nbiny <<" ";
cout<<"nbinz:"<< nbinz <<" ";
cout<<"\n";

int n_pts = (nbinx+1)*(nbiny+1)*(nbinz+1); 
vector<double> pts;  
for(int i=0,l=0; i<nbinx+1; i++)
{
  for(int j=0; j<nbiny+1; j++) 
  {
    for(int k=0; k<nbinz+1; k++, l++) 
    {
      pts.push_back( bboxlo[0] + i * binsizex );  
      pts.push_back( bboxlo[1] + j * binsizey );
      pts.push_back( bboxlo[2] + k * binsizez );
    }
  }
}


    }

    void center2vertex(double* center, double dx, double dy, double dz)
    {
      double vertices[8][3] = { 
                                {-dx*0.5, -dy*0.5, -dz*0.5}, 
                                { dx*0.5, -dy*0.5, -dz*0.5}, 
                                { dx*0.5,  dy*0.5, -dz*0.5},
                                {-dx*0.5,  dy*0.5, -dz*0.5}, 
                                {-dx*0.5, -dy*0.5,  dz*0.5},
                                { dx*0.5, -dy*0.5,  dz*0.5},
                                { dx*0.5,  dy*0.5,  dz*0.5},
                                {-dx*0.5,  dy*0.5,  dz*0.5} 
                              };  

      for(int i=0; i<8; i++)
      {
        cout<<" | ";
        for(int j=0; j<3; j++) cout<< center[j] + vertices[i][j] <<" "; 
        cout<<" | ";
      }
cout<<"\n";

    }


/*
  7-6 
 / / 
4-5 
  3-2
 / /
0-1 

0: (-dx/2,-dy/2,-dz/2) 
1: ( dx/2,-dy/2,-dz/2)
2: ( dx/2, dy/2,-dz/2)
3: (-dx/2, dy/2,-dz/2)
4: (-dx/2,-dy/2, dz/2) 
5: ( dx/2,-dy/2, dz/2)
6: ( dx/2, dy/2, dz/2)
7: (-dx/2, dy/2, dz/2)

*/

    class NeighList *list;

    vector<int>     connectivity;
    vector<double>  pts;


}; // CfdDatacouplingCommdom 

} // LAMMPS_NS 

#endif // CfdDatacouplingCommdom 
#endif // CFD_DATACOUPLING_CLASS  
