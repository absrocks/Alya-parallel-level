namespace LAMMPS_NS {class FixRemove { public: void delete_bodies(){} };}
