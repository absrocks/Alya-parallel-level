/*
  CREATED: 2016FEB15 @ Barcelona, Spain   
  FROM: coupling_file.h 
*/

#ifndef CFD_COMMDOM_H
#define CFD_COMMDOM_H

#ifdef COMMDOM 
#include "commdom.hpp"
#endif

#include <map>
#include "pointers.h"

namespace LAMMPS_NS {

class CfdCommdom : protected Pointers 
{
  public:

  CfdCommdom(LAMMPS *lmp) : Pointers(lmp)
  {
    _app_type = "LIGGGHTS";
       myself = "DEM"; 
        namei = "---";

     WORLD_COMM = MPI_COMM_NULL; 
    _LOCAL_COMM = MPI_COMM_NULL;

    CD = CommDom();

    DIM      = 3; 
    n_cplngs = 0; 
  }


  virtual ~CfdCommdom() 
  {
    
  }


  MPI_Comm init(int m_argc, char** m_argv, MPI_Comm _WORLD_COMM)
  {
    if( m_argv[1] == myself )
    {
      namei         = m_argv[1];
      Commij["CFD"] = MPI_COMM_NULL;
    } 

    WORLD_COMM = _WORLD_COMM; 
   _LOCAL_COMM =  WORLD_COMM; 

#ifdef COMMDOM 
    CD.init();
    CD.set_app_type( _app_type );
    CD.set_app_name( namei );
    CD.set_world_comm( WORLD_COMM );

    _LOCAL_COMM = CD.set_mpi_comms();
#endif

    init_comms(); 

    return _LOCAL_COMM;
  }


  void init_comms()
  {
    for(It = Commij.begin(); It != Commij.end(); ++It)
    {
      string     namej = It->first;
      MPI_Comm  commij = It->second;
      if( (CD.__get_friends__(namej)==1) ) 
      {
        Commij[namej] = CD.get_mpi_commij(namej);
      }
    }
  }


  void set_bins(double *bboxlo, double* bboxhi, double* binsize, int* nbin, int* mbin, int* mbinlo)
  {
/* 
    mless = new MeshLess();
    mless->set_bbox( bboxlo, bboxhi );
    mless->set_binsize( binsize[0], binsize[1], binsize[2] );
    mless->set_nbin( nbin[0], nbin[1], nbin[2] ); 
    mless->set_mbin( mbin[0], mbin[1], mbin[2] );
    mless->set_mbinlo( mbinlo[0], mbinlo[1], mbinlo[2] );
*/
  }


  void set_vertex_coords_j(int n_coords, double**  coords)
  {
           n_vertices_j = 0;
    vertex_coords_j_ptr = NULL;

    if(n_coords != 0) 
    { 
             n_vertices_j = n_coords;  
      vertex_coords_j_ptr = new double[n_vertices_j*DIM]; 

      for(int i=0,l=0; i<n_vertices_j; i++)
      {
        for(int j=0; j<DIM; j++) vertex_coords_j_ptr[l++] = coords[i][j];  
      }
    } 
  }


  void set_vertex_coords_i(int n_coords, double* coords, int n_elements, int* vertex_num)
  {
           n_vertices_i = 0;
    vertex_coords_i_ptr = NULL;

    if(n_coords != 0)
    {
             n_vertices_i = n_coords;
      vertex_coords_i_ptr = coords;
    }

         n_elements_i = 0;
     vertex_num_i_ptr = NULL;
    vertex_type_i_ptr = NULL;

    if(n_elements != 0)
    {
           n_elements_i = n_elements;
       vertex_num_i_ptr = new int[n_elements_i*8];
      vertex_type_i_ptr = new int[n_elements_i  ]; 

      for(int i=0; i<n_elements_i*8; i++)  vertex_num_i_ptr[i] = vertex_num[i];
      for(int i=0; i<n_elements_i  ; i++) vertex_type_i_ptr[i] = 37;  

for(int i=0,k=0; i<n_elements_i; i++) 
{
  for(int j=0; j<8; j++, k++) 
  {
    int   idx = vertex_num[k];  
    double  x = coords[idx+0];  
    double  y = coords[idx+1];
    double  z = coords[idx+2]; 

//    cout<<  <<" ";
  }
//  cout<<"\n";
}
    }

  }  


  void clear_vertex_coords_j()
  {
    n_vertices_j = 0; 
    delete[] vertex_coords_j_ptr; 
    vertex_coords_j_ptr = NULL; 
  }


  void create_geometry(int itime)  
  { 
    cout<<"[create_geometry] n_cplngs:"<<  n_cplngs <<"\n";

    for(It = Commij.begin(); It != Commij.end(); ++It)
    {
      string    namej  = It->first;
      MPI_Comm  commij = It->second;

      tolerance = 1e-3; 

      if(commij != MPI_COMM_NULL)
      {
        CD.locator_create2(_LOCAL_COMM, commij, tolerance);

        CD.locator_set_cs_mesh(n_vertices_i,
                               n_elements_i,
                               vertex_coords_i_ptr,
                               vertex_num_i_ptr,
                               vertex_type_i_ptr,
                               n_vertices_j,
                               vertex_coords_j_ptr);

        CD.save_dist_coords(n_cplngs, _LOCAL_COMM);

        // Data to send 
        int n_send = CD.get_n_dist_points();
        double* var_ij = new double[ n_send ];
        for(int i=0; i<n_send; i++) var_ij[i] = 0.0;

        // Data to recv
        int n_recv = CD.get_n_interior();
        double* var_ji = new double[ n_recv ];
        for(int i=0; i<n_recv; i++) var_ji[i] = 0.0;

        // Exchange  
        CD.__locator_exchange_double_scalar__(var_ij, var_ji); 

for(int i=0; i<n_recv; i++) cout<< var_ji[i] <<" ";
cout<<"\n";

        CD.locator_destroy();
      }
    }

    n_cplngs++;
  } 


  private:
    map<std::string,MPI_Comm>            Commij;
    map<std::string,MPI_Comm>::iterator  It;

    MPI_Comm  _LOCAL_COMM;  
    MPI_Comm  WORLD_COMM;

    std::string  _app_type;  
    std::string  namei;
    std::string  myself;

    CommDom  CD;  

    double tolerance; 

    int            n_cplngs; 
    int            DIM; 
    int            n_vertices_j;
    double* vertex_coords_j_ptr;

    int            n_vertices_i;
    double* vertex_coords_i_ptr;

    int       n_elements_i;
    int*  vertex_num_i_ptr;
    int* vertex_type_i_ptr;

}; // CfdDatacouplingCommdom 

} // LAMMPS_NS 

#endif // CfdDatacouplingCommdom 

/*
  int *location = new int[n_coords];
  memset(location, 0.0, n_coords);

  float *distance = new float[n_coords];
  memset(distance, 0.0, n_coords);

  locate_inside_f(     Mesh,      tol,
                   n_coords,   coords,
                   location, distance);

  + locate_inside_f 
  |_ 1)  octree = build_octree( coords ); 
  |_ 2) _mesh_locate_3d( Mesh, octree ) 
    |_ for element in Mesh
      |_ 2.1)            extent = get_extents( element ) 
      |_ 2.2) points_in_extents = query_octree( octree, coords, extent ) 
      |_ 2.3) elt_num, distance = locate_in_element( points_in_extents, element )  
              location = element id  
              distance = distance between point to locate and its projection 

      |_ 2.1)            extent = get_bin_extents( )
      |_ 2.3) elt_num, distance = locate_in_bin( points_in_extents, bin )  









*/

/*
// the function using the function pointers:
void somefunction(void (*fptr)(void*, int, int), void* context) {
    fptr(context, 17, 42);
}

void non_member(void*, int i0, int i1) {
    std::cout << "I don't need any context! i0=" << i0 << " i1=" << i1 << "\n";
}

struct foo {
    void member(int i0, int i1) {
        std::cout << "member function: this=" << this << " i0=" << i0 << " i1=" << i1 << "\n";
    }
};

void forwarder(void* context, int i0, int i1) {
    static_cast<foo*>(context)->member(i0, i1);
}

int main() {
    somefunction(&non_member, 0);
    foo object;
    somefunction(&forwarder, &object);
}
*/
