#include "fix_contact_property_atom_dummy.h"
