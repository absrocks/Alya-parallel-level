void forward_comm() {} void reverse_comm() {}
